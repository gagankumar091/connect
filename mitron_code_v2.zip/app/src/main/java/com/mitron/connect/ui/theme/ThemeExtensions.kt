package com.mitron.connect.ui.theme

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Modifier
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ContentColor
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProgressIndicatorDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarDefaults
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButtonDefaults
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawArc
import androidx.compose.ui.graphics.drawscope.drawRect
import androidx.compose.ui.graphics.drawscope.fill
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Measurable
import androidx.compose.ui.layout.MeasureResult
import androidx.compose.ui.layout.MeasureScope
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ─────────────────────────────────────────────────────────────────────────────
// THEME ACCESSORS - Semantic Color Tokens
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun ConnectTheme.colors: ConnectColorScheme = LocalConnectColors.current

@Composable
fun MaterialTheme.connectColors: ConnectColorScheme = LocalConnectColors.current

val ColorScheme.success: Color
    @Composable
    get() = LocalConnectColors.current.success

val ColorScheme.onSuccess: Color
    @Composable
    get() = LocalConnectColors.current.onSuccess

val ColorScheme.successContainer: Color
    @Composable
    get() = LocalConnectColors.current.successContainer

val ColorScheme.onSuccessContainer: Color
    @Composable
    get() = LocalConnectColors.current.onSuccessContainer

val ColorScheme.warn: Color
    @Composable
    get() = LocalConnectColors.current.warn

val ColorScheme.onWarn: Color
    @Composable
    get() = LocalConnectColors.current.onWarn

val ColorScheme.warnContainer: Color
    @Composable
    get() = LocalConnectColors.current.warnContainer

val ColorScheme.onWarnContainer: Color
    @Composable
    get() = LocalConnectColors.current.onWarnContainer

val ColorScheme.danger: Color
    @Composable
    get() = LocalConnectColors.current.danger

val ColorScheme.onDanger: Color
    @Composable
    get() = LocalConnectColors.current.onDanger

val ColorScheme.dangerContainer: Color
    @Composable
    get() = LocalConnectColors.current.dangerContainer

val ColorScheme.onDangerContainer: Color
    @Composable
    get() = LocalConnectColors.current.onDangerContainer

val ColorScheme.brand: Color
    @Composable
    get() = LocalConnectColors.current.brand

val ColorScheme.onBrand: Color
    @Composable
    get() = LocalConnectColors.current.onBrand

val ColorScheme.brandContainer: Color
    @Composable
    get() = LocalConnectColors.current.brandContainer

val ColorScheme.onBrandContainer: Color
    @Composable
    get() = LocalConnectColors.current.onBrandContainer

val ColorScheme.ai: Color
    @Composable
    get() = LocalConnectColors.current.ai

val ColorScheme.onAi: Color
    @Composable
    get() = LocalConnectColors.current.onAi

val ColorScheme.aiContainer: Color
    @Composable
    get() = LocalConnectColors.current.aiContainer

val ColorScheme.onAiContainer: Color
    @Composable
    get() = LocalConnectColors.current.onAiContainer

val ColorScheme.glassLight: Color
    @Composable
    get() = Color.White.copy(alpha = 0.6f)

val ColorScheme.glassBorderLight: Color
    @Composable
    get() = Color.White.copy(alpha = 0.4f)

val ColorScheme.glassDark: Color
    @Composable
    get() = Color(0xFF1F2937).copy(alpha = 0.6f)

val ColorScheme.glassBorderDark: Color
    @Composable
    get() = Color(0xFF374151).copy(alpha = 0.4f)

val ColorScheme.glass: Color
    @Composable
    get() = if (MaterialTheme.colorScheme.isLight) MaterialTheme.colorScheme.glassLight else MaterialTheme.colorScheme.glassDark

val ColorScheme.glassBorder: Color
    @Composable
    get() = if (MaterialTheme.colorScheme.isLight) MaterialTheme.colorScheme.glassBorderLight else MaterialTheme.colorScheme.glassBorderDark

// ─────────────────────────────────────────────────────────────────────────────
// SPACING & TYPOGRAPHY HELPERS
// ─────────────────────────────────────────────────────────────────────────────

object Spacing {
    val space4 = 4.dp
    val space8 = 8.dp
    val space12 = 12.dp
    val space16 = 16.dp
    val space24 = 24.dp
    val space32 = 32.dp
    val space48 = 48.dp
    val space64 = 64.dp

    // Semantic aliases
    val xs = space4
    val sm = space8
    val md = space16
    val lg = space24
    val xl = space32
    val xxl = space48

    // Component-specific
    val screenHorizontal = space24
    val screenVertical = space24
    val cardPadding = space16
    val cardGap = space12
    val chipGap = space8
    val fabMargin = space16
}

object TypeStyle {
    // Display
    val displayLarge = MaterialTheme.typography.displayLarge
    val displayMedium = MaterialTheme.typography.displayMedium
    val displaySmall = MaterialTheme.typography.displaySmall

    // Headline
    val headlineLarge = MaterialTheme.typography.headlineLarge
    val headlineMedium = MaterialTheme.typography.headlineMedium
    val headlineSmall = MaterialTheme.typography.headlineSmall

    // Title
    val titleLarge = MaterialTheme.typography.titleLarge
    val titleMedium = MaterialTheme.typography.titleMedium
    val titleSmall = MaterialTheme.typography.titleSmall

    // Body
    val bodyLarge = MaterialTheme.typography.bodyLarge
    val bodyMedium = MaterialTheme.typography.bodyMedium
    val bodySmall = MaterialTheme.typography.bodySmall

    // Label
    val labelLarge = MaterialTheme.typography.labelLarge
    val labelMedium = MaterialTheme.typography.labelMedium
    val labelSmall = MaterialTheme.typography.labelSmall
}

// ─────────────────────────────────────────────────────────────────────────────
// GRADIENT PRESETS
// ─────────────────────────────────────────────────────────────────────────────

object Gradients {
    @Composable
    fun primary(): Brush = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
        )
    )

    @Composable
    fun primaryVertical(): Brush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.primaryContainer
        )
    )

    @Composable
    fun brand(): Brush = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.brand,
            MaterialTheme.colorScheme.brand.copy(alpha = 0.8f)
        )
    )

    @Composable
    fun success(): Brush = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.success,
            MaterialTheme.colorScheme.success.copy(alpha = 0.8f)
        )
    )

    @Composable
    fun danger(): Brush = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.danger,
            MaterialTheme.colorScheme.danger.copy(alpha = 0.8f)
        )
    )

    @Composable
    fun glass(): Brush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.glass,
            MaterialTheme.colorScheme.glass.copy(alpha = 0.3f)
        )
    )

    @Composable
    fun surfaceTint(): Brush = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surface,
            MaterialTheme.colorScheme.surfaceContainerLow
        )
    )

    @Composable
    fun radialGlow(color: Color = MaterialTheme.colorScheme.primary): Brush = Brush.radialGradient(
        center = Offset(0.5f, 0.5f),
        radius = 0.8f,
        colors = listOf(
            color.copy(alpha = 0.15f),
            Color.Transparent
        )
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// SHAPE PRESETS
// ─────────────────────────────────────────────────────────────────────────────

object Shapes {
    val xs = RoundedCornerShape(4.dp)
    val sm = RoundedCornerShape(8.dp)
    val md = RoundedCornerShape(12.dp)
    val lg = RoundedCornerShape(16.dp)
    val xl = RoundedCornerShape(24.dp)
    val xxl = RoundedCornerShape(32.dp)
    val pill = RoundedCornerShape(999.dp)
    val circle = CircleShape

    // Component-specific
    val card = xl
    val button = md
    val chip = pill
    val fab = xl
    val dialog = xl
    val bottomSheet = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    val avatar = circle
    val badge = pill
}

// ─────────────────────────────────────────────────────────────────────────────
// ELEVATION / SHADOW PRESETS
// ─────────────────────────────────────────────────────────────────────────────

object Elevation {
    val level0 = 0.dp
    val level1 = 1.dp
    val level2 = 3.dp
    val level3 = 6.dp
    val level4 = 12.dp
    val level5 = 24.dp

    @Composable
    fun card(): CardDefaults.CardElevation = CardDefaults.cardElevation(
        defaultElevation = level1,
        pressedElevation = level2,
        focusedElevation = level2,
        hoveredElevation = level2
    )

    @Composable
    fun elevatedCard(): CardDefaults.CardElevation = CardDefaults.cardElevation(
        defaultElevation = level3,
        pressedElevation = level4,
        focusedElevation = level4,
        hoveredElevation = level4
    )

    @Composable
    fun fab(): androidx.compose.material3.FabDefaults.FabElevation = androidx.compose.material3.FabDefaults.fabElevation(
        defaultElevation = level3,
        pressedElevation = level4,
        focusedElevation = level4,
        hoveredElevation = level4
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// MODIFIER EXTENSIONS
// ─────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
fun Modifier.glassCard(
    shape: androidx.compose.ui.graphics.Shape = Shapes.card,
    elevation: CardDefaults.CardElevation = Elevation.card(),
    borderWidth: Dp = 1.dp
): Modifier = this
    .background(MaterialTheme.colorScheme.glass, shape)
    .border(borderWidth, MaterialTheme.colorScheme.glassBorder, shape)
    .shadow(elevation.defaultElevation, shape, spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))

@OptIn(ExperimentalMaterial3Api::class)
fun Modifier.surfaceCard(
    containerColor: Color = MaterialTheme.colorScheme.surface,
    shape: androidx.compose.ui.graphics.Shape = Shapes.card,
    elevation: CardDefaults.CardElevation = Elevation.card()
): Modifier = this
    .background(containerColor, shape)
    .shadow(elevation.defaultElevation, shape, spotColor = Color.Black.copy(alpha = 0.05f))

fun Modifier.primaryGradient(
    shape: androidx.compose.ui.graphics.Shape = Shapes.button
): Modifier = this
    .background(Gradients.primary(), shape)

fun Modifier.brandGradient(
    shape: androidx.compose.ui.graphics.Shape = Shapes.button
): Modifier = this
    .background(Gradients.brand(), shape)

fun Modifier.successGradient(
    shape: androidx.compose.ui.graphics.Shape = Shapes.button
): Modifier = this
    .background(Gradients.success(), shape)

fun Modifier.dangerGradient(
    shape: androidx.compose.ui.graphics.Shape = Shapes.button
): Modifier = this
    .background(Gradients.danger(), shape)

fun Modifier.glow(
    color: Color = MaterialTheme.colorScheme.primary,
    radius: Dp = 24.dp
): Modifier = this
    .background(Gradients.radialGlow(color), Shapes.circle)
    .size(radius)

fun Modifier.clipToBounds(shape: androidx.compose.ui.graphics.Shape = Shapes.card): Modifier = this
    .clip(shape)

fun Modifier.inkWell(
    onClick: () -> Unit,
    shape: androidx.compose.ui.graphics.Shape = Shapes.md,
    pressedAlpha: Float = 0.1f
): Modifier = this
    .clickable(onClick = onClick)
    .background(Color.Transparent, shape) // Ripple handled by Material

fun Modifier.safePadding(): Modifier = this
    .padding(
        start = androidx.compose.foundation.layout.WindowInsets.safeDrawing.left,
        top = androidx.compose.foundation.layout.WindowInsets.safeDrawing.top,
        end = androidx.compose.foundation.layout.WindowInsets.safeDrawing.right,
        bottom = androidx.compose.foundation.layout.WindowInsets.safeDrawing.bottom
    )

fun Modifier.statusBarsPadding(): Modifier = this
    .padding(top = androidx.compose.foundation.layout.WindowInsets.statusBars.top)

fun Modifier.navigationBarsPadding(): Modifier = this
    .padding(bottom = androidx.compose.foundation.layout.WindowInsets.navigationBars.bottom)

fun Modifier.systemBarsPadding(): Modifier = this
    .statusBarsPadding()
    .navigationBarsPadding()

// ─────────────────────────────────────────────────────────────────────────────
// ANIMATION PRESETS
// ─────────────────────────────────────────────────────────────────────────────

object Anim {
    val fastSpring = spring(dampingRatio = 0.8f, stiffness = 400f)
    val mediumSpring = spring(dampingRatio = 0.7f, stiffness = 300f)
    val slowSpring = spring(dampingRatio = 0.6f, stiffness = 200f)
    val bouncySpring = spring(dampingRatio = 0.5f, stiffness = 150f)

    val fastTween = tween(150, easing = androidx.compose.animation.core.Easing.FastOutSlowInEasing)
    val mediumTween = tween(250, easing = androidx.compose.animation.core.Easing.FastOutSlowInEasing)
    val slowTween = tween(400, easing = androidx.compose.animation.core.Easing.FastOutSlowInEasing)

    val enterFade = fadeIn(mediumTween) + slideIntoVertically(-Spacing.space8, mediumTween)
    val exitFade = fadeOut(fastTween) + slideOutVertically(Spacing.space8, fastTween)

    val enterScale = expandIn(Shapes.md, mediumSpring)
    val exitScale = shrinkOut(Shapes.md, fastSpring)
}

// ─────────────────────────────────────────────────────────────────────────────
// TEXT STYLE EXTENSIONS
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun TextStyle(
    style: TextStyle = MaterialTheme.typography.bodyLarge,
    color: Color = MaterialTheme.colorScheme.onSurface,
    fontWeight: FontWeight? = null,
    fontSize: androidx.compose.ui.unit.Sp? = null,
    lineHeight: androidx.compose.ui.unit.Sp? = null,
    letterSpacing: androidx.compose.ui.unit.Sp? = null,
    textAlign: TextAlign? = null,
    maxLines: Int? = null,
    overflow: TextOverflow = TextOverflow.Ellipsis
): TextStyle = style.copy(
    color = color,
    fontWeight = fontWeight,
    fontSize = fontSize,
    lineHeight = lineHeight,
    letterSpacing = letterSpacing,
    textAlign = textAlign,
    maxLines = maxLines,
    overflow = overflow
)

// ─────────────────────────────────────────────────────────────────────────────
// REUSABLE UI PRIMITIVES
// ─────────────────────────────────────────────────────────────────────────────

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun ConnectSurface(
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = Shapes.card,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    elevation: CardDefaults.CardElevation = Elevation.card(),
    borderWidth: Dp = 0.dp,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
    content: @Composable () -> Unit
) {
    androidx.compose.material3.Surface(
        modifier = modifier,
        shape = shape,
        color = containerColor,
        contentColor = contentColor,
        elevation = elevation,
        border = if (borderWidth > 0.dp) androidx.compose.foundation.BorderStroke(borderWidth, borderColor) else null
    ) {
        content()
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun ConnectCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    shape: androidx.compose.ui.graphics.Shape = Shapes.card,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    elevation: CardDefaults.CardElevation = Elevation.card(),
    borderWidth: Dp = 0.dp,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
    content: @Composable () -> Unit
) {
    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val isPressed = interactionSource.collectIsPressedAsState()

    androidx.compose.material3.Card(
        modifier = modifier
            .fillMaxWidth()
            .animateScale(
                targetValue = if (isPressed.value) 0.98f else 1f,
                animationSpec = Anim.fastSpring,
                label = "cardScale"
            ),
        onClick = onClick,
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        elevation = elevation,
        border = if (borderWidth > 0.dp) androidx.compose.foundation.BorderStroke(borderWidth, borderColor) else null
    ) {
        content()
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun ConnectButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    variant: ButtonVariant = ButtonVariant.Filled,
    shape: androidx.compose.ui.graphics.Shape = Shapes.button,
    height: Dp = 48.dp,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val (containerColor, contentColor) = when (variant) {
        ButtonVariant.Filled -> MaterialTheme.colorScheme.primary to MaterialTheme.colorScheme.onPrimary
        ButtonVariant.Tonal -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
        ButtonVariant.Outlined -> Color.Transparent to MaterialTheme.colorScheme.primary
        ButtonVariant.Ghost -> Color.Transparent to MaterialTheme.colorScheme.onSurface
        ButtonVariant.Danger -> MaterialTheme.colorScheme.danger to MaterialTheme.colorScheme.onDanger
        ButtonVariant.Success -> MaterialTheme.colorScheme.success to MaterialTheme.colorScheme.onSuccess
        ButtonVariant.Brand -> MaterialTheme.colorScheme.brand to MaterialTheme.colorScheme.onBrand
    }

    val border = when (variant) {
        ButtonVariant.Outlined -> androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
        ButtonVariant.Ghost -> androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        else -> null
    }

    androidx.compose.material3.Button(
        onClick = onClick,
        modifier = modifier
            .height(height)
            .fillMaxWidth(),
        enabled = enabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
            disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
        ),
        border = border
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            leadingIcon?.invoke()
            if (leadingIcon != null) Spacer(Modifier.width(Spacing.space8))
            content()
            if (trailingIcon != null) Spacer(Modifier.width(Spacing.space8))
            trailingIcon?.invoke()
        }
    }
}

enum class ButtonVariant {
    Filled, Tonal, Outlined, Ghost, Danger, Success, Brand
}

@Composable
fun ConnectIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    variant: IconButtonVariant = IconButtonVariant.Standard,
    size: Dp = 40.dp,
    content: @Composable () -> Unit
) {
    val (containerColor, contentColor) = when (variant) {
        IconButtonVariant.Standard -> MaterialTheme.colorScheme.surfaceContainerHigh to MaterialTheme.colorScheme.onSurface
        IconButtonVariant.Primary -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        IconButtonVariant.Glass -> MaterialTheme.colorScheme.glass to MaterialTheme.colorScheme.onSurface
        IconButtonVariant.Danger -> MaterialTheme.colorScheme.dangerContainer to MaterialTheme.colorScheme.onDangerContainer
    }

    val border = when (variant) {
        IconButtonVariant.Glass -> androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.glassBorder)
        else -> null
    }

    androidx.compose.material3.IconButton(
        onClick = onClick,
        modifier = modifier.size(size),
        enabled = enabled,
        colors = IconButtonDefaults.iconButtonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
            disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
        ),
        border = border
    ) {
        content()
    }
}

enum class IconButtonVariant {
    Standard, Primary, Glass, Danger
}

@Composable
fun ConnectChip(
    label: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    badgeCount: Int = 0
) {
    val containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh
    val contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface

    Box(
        modifier = modifier
            .height(36.dp)
            .padding(horizontal = Spacing.space16)
            .clip(Shapes.chip)
            .background(containerColor)
            .clickable(onClick = onClick)
            .animateColorAsState(targetValue = containerColor, animationSpec = Anim.fastTween),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Spacing.space8)
        ) {
            leadingIcon?.invoke()
            Text(
                text = label,
                color = contentColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            trailingIcon?.invoke()
            if (badgeCount > 0) {
                Badge(badgeCount, contentColor)
            }
        }
    }
}

@Composable
private fun Badge(count: Int, contentColor: Color) {
    Box(
        modifier = Modifier
            .size(18.dp)
            .background(if (count > 99) MaterialTheme.colorScheme.danger else MaterialTheme.colorScheme.primary, Shapes.circle),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (count > 99) "99+" else count.toString(),
            color = contentColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ConnectAvatar(
    modifier: Modifier = Modifier,
    name: String,
    imageUrl: String? = null,
    size: Dp = 48.dp,
    shape: androidx.compose.ui.graphics.Shape = Shapes.circle,
    borderWidth: Dp = 0.dp,
    borderColor: Color = MaterialTheme.colorScheme.primary
) {
    val initials = name.split(" ").joinToString("") { it.firstOrNull()?.uppercase() ?: "" }.take(2)
    val colorIndex = name.hashCode().absoluteValue % ConnectColorScheme.avatarColors.size
    val bgColor = ConnectColorScheme.avatarColors[colorIndex]
    val fgColor = if (bgColor.luminance() > 0.5f) Color.Black else Color.White

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .border(borderWidth, borderColor, shape)
    ) {
        if (!imageUrl.isNullOrBlank() && imageUrl != "null") {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(imageUrl).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                placeholder = { painterResource("placeholder") },
                error = { painterResource("error") }
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(bgColor, shape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initials,
                    color = fgColor,
                    fontSize = (size.value * 0.4).sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ConnectStatusIndicator(
    modifier: Modifier = Modifier,
    isOnline: Boolean,
    size: Dp = 12.dp,
    borderWidth: Dp = 2.dp,
    borderColor: Color = MaterialTheme.colorScheme.surface
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(Shapes.circle)
            .background(if (isOnline) MaterialTheme.colorScheme.success else MaterialTheme.colorScheme.outline, Shapes.circle)
            .border(borderWidth, borderColor, Shapes.circle)
    )
}

@Composable
fun ConnectCircularProgress(
    modifier: Modifier = Modifier,
    progress: Float, // 0..1
    strokeWidth: Dp = 8.dp,
    size: Dp = 64.dp,
    trackColor: Color = MaterialTheme.colorScheme.surfaceContainerHigh,
    progressColor: Color = MaterialTheme.colorScheme.primary,
    trackColorDark: Color = MaterialTheme.colorScheme.surfaceContainerHighest,
    progressGradient: Brush? = null
) {
    Canvas(
        modifier = modifier.size(size),
        onDraw = {
            val radius = (size.toPx() - strokeWidth.toPx()) / 2
            val center = Offset(size.toPx() / 2f, size.toPx() / 2f)
            val sweepAngle = 360f * progress

            // Track
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = androidx.compose.ui.graphics.Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
            )

            // Progress
            drawArc(
                brush = progressGradient ?: Brush.solidColor(progressColor),
                startAngle = -90f,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = androidx.compose.ui.graphics.Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
            )
        }
    )
}

@Composable
fun ConnectDivider(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.outlineVariant,
    thickness: Dp = 1.dp,
    startIndent: Dp = 0.dp,
    endIndent: Dp = 0.dp
) {
    androidx.compose.material3.Divider(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = startIndent, end = endIndent),
        color = color,
        thickness = thickness
    )
}

@Composable
fun ConnectSpacer(modifier: Modifier = Modifier, dimension: Dp = Spacing.md) {
    androidx.compose.foundation.layout.Spacer(modifier.size(dimension))
}

@Composable
fun ConnectEmptyState(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.outline,
            modifier = Modifier.size(64.dp)
        )
        ConnectSpacer(dimension = Spacing.lg)
        Text(
            text = title,
            style = TypeStyle.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        ConnectSpacer(dimension = Spacing.sm)
        Text(
            text = subtitle,
            style = TypeStyle.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (actionLabel != null && onAction != null) {
            ConnectSpacer(dimension = Spacing.xl)
            ConnectButton(
                onClick = onAction,
                variant = ButtonVariant.Filled,
                modifier = Modifier.padding(horizontal = Spacing.xl)
            ) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
fun ConnectTopAppBar(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String? = null,
    leadingIcon: ImageVector? = Icons.Filled.ArrowBack,
    onLeadingClick: (() -> Unit)? = null,
    trailingIcons: List<TrailingIcon> = emptyList(),
    backgroundColor: Color = MaterialTheme.colorScheme.surface,
    scrollBehavior: androidx.compose.material3.TopAppBarScrollBehavior? = null
) {
    androidx.compose.material3.TopAppBar(
        modifier = modifier,
        title = {
            Column {
                Text(
                    text = title,
                    style = TypeStyle.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                subtitle?.let {
                    Text(
                        text = it,
                        style = TypeStyle.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        navigationIcon = leadingIcon?.let {
            {
                ConnectIconButton(
                    onClick = onLeadingClick ?: {},
                    variant = IconButtonVariant.Glass,
                    size = 40.dp
                ) {
                    Icon(it, contentDescription = "Navigate back", tint = MaterialTheme.colorScheme.onSurface)
                }
            }
        },
        actions = {
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                trailingIcons.forEach { item ->
                    ConnectIconButton(
                        onClick = item.onClick,
                        variant = item.variant,
                        size = 40.dp
                    ) {
                        Icon(item.icon, contentDescription = item.contentDescription, tint = item.tintColor)
                        if (item.badgeCount > 0) {
                            Badge(item.badgeCount, item.tintColor)
                        }
                    }
                }
            }
        },
        colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
            containerColor = backgroundColor,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            navigationIconContentColor = MaterialTheme.colorScheme.onSurface,
            actionIconContentColor = MaterialTheme.colorScheme.onSurface
        ),
        scrollBehavior = scrollBehavior
    )
}

data class TrailingIcon(
    val icon: ImageVector,
    val onClick: () -> Unit,
    val contentDescription: String,
    val variant: IconButtonVariant = IconButtonVariant.Glass,
    val tintColor: Color = MaterialTheme.colorScheme.onSurface,
    val badgeCount: Int = 0
)

// ─────────────────────────────────────────────────────────────────────────────
// LOADING STATES
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun ConnectShimmer(
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = Shapes.md,
    baseColor: Color = MaterialTheme.colorScheme.surfaceContainerHigh,
    highlightColor: Color = MaterialTheme.colorScheme.surfaceContainerLowest
) {
    androidx.compose.material3.Surface(
        modifier = modifier,
        shape = shape,
        color = baseColor
    ) {
        androidx.compose.animation.core.Shimmer(
            modifier = Modifier.fillMaxSize(),
            shape = shape,
            baseColor = baseColor,
            highlightColor = highlightColor
        )
    }
}

@Composable
fun ConnectSkeleton(
    modifier: Modifier = Modifier,
    lines: Int = 3,
    lineHeight: Dp = 16.dp,
    gap: Dp = 8.dp,
    widthPercent: Float = 1f
) {
    Column(modifier = modifier) {
        repeat(lines) { index ->
            val w = if (index == lines - 1) widthPercent * 0.6f else widthPercent
            ConnectShimmer(
                modifier = Modifier
                    .fillMaxWidth(w)
                    .height(lineHeight)
            )
            if (index < lines - 1) ConnectSpacer(dimension = gap)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TEXT FIELD
// ─────────────────────────────────────────────────────────────────────────────

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun ConnectTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String,
    placeholder: String? = null,
    leadingIcon: ImageVector? = null,
    trailingIcon: ImageVector? = null,
    onTrailingClick: (() -> Unit)? = null,
    isError: Boolean = false,
    errorMessage: String? = null,
    singleLine: Boolean = true,
    keyboardOptions: androidx.compose.ui.text.input.KeyboardOptions = androidx.compose.ui.text.input.KeyboardOptions.Default,
    keyboardActions: androidx.compose.ui.text.input.KeyboardActions = androidx.compose.ui.text.input.KeyboardActions.Default,
    visualTransformation: androidx.compose.ui.text.input.VisualTransformation = androidx.compose.ui.text.input.VisualTransformation.None
) {
    var showError by remember { mutableStateOf(isError && errorMessage != null) }

    androidx.compose.material3.TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(Anim.mediumSpring),
        label = { Text(text = label, style = TypeStyle.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        placeholder = placeholder?.let { { Text(text = it, style = TypeStyle.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) } },
        leadingIcon = leadingIcon?.let { { Icon(it, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) } },
        trailingIcon = trailingIcon?.let { {
            IconButton(onClick = onTrailingClick ?: {}) {
                Icon(it, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } },
        isError = isError,
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        visualTransformation = visualTransformation,
        colors = TextFieldDefaults.textFieldColors(
            containerColor = MaterialTheme.colorScheme.surface,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
            focusedLabelColor = MaterialTheme.colorScheme.primary,
            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            cursorColor = MaterialTheme.colorScheme.primary,
            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
            unfocusedIndicatorColor = MaterialTheme.colorScheme.outlineVariant,
            disabledIndicatorColor = MaterialTheme.colorScheme.outline,
            errorIndicatorColor = MaterialTheme.colorScheme.danger,
            errorContainerColor = MaterialTheme.colorScheme.dangerContainer,
            errorContentColor = MaterialTheme.colorScheme.onDangerContainer,
            placeholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        ),
        shape = Shapes.md
    )

    if (showError && errorMessage != null) {
        ConnectSpacer(dimension = Spacing.xs)
        Text(
            text = errorMessage,
            style = TypeStyle.labelMedium,
            color = MaterialTheme.colorScheme.danger
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// LISTS & GRIDS
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun ConnectLazyColumn(
    modifier: Modifier = Modifier,
    contentPadding: androidx.compose.foundation.layout.PaddingValues = PaddingValues(Spacing.screenHorizontal, Spacing.screenVertical),
    verticalArrangement: Arrangement.Vertical = Arrangement.spacedBy(Spacing.cardGap),
    content: @Composable androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier = modifier,
        contentPadding = contentPadding,
        verticalArrangement = verticalArrangement
    ) {
        content()
    }
}

@Composable
fun ConnectLazyRow(
    modifier: Modifier = Modifier,
    contentPadding: androidx.compose.foundation.layout.PaddingValues = PaddingValues(Spacing.screenHorizontal, 0.dp),
    horizontalArrangement: Arrangement.Horizontal = Arrangement.spacedBy(Spacing.cardGap),
    content: @Composable androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    androidx.compose.foundation.lazy.LazyRow(
        modifier = modifier,
        contentPadding = contentPadding,
        horizontalArrangement = horizontalArrangement
    ) {
        content()
    }
}

@Composable
fun ConnectLazyGrid(
    modifier: Modifier = Modifier,
    columns: Int = 2,
    contentPadding: androidx.compose.foundation.layout.PaddingValues = PaddingValues(Spacing.screenHorizontal, Spacing.screenVertical),
    verticalArrangement: Arrangement.Vertical = Arrangement.spacedBy(Spacing.cardGap),
    horizontalArrangement: Arrangement.Horizontal = Arrangement.spacedBy(Spacing.cardGap),
    content: @Composable androidx.compose.foundation.lazy.grid.LazyGridScope.() -> Unit
) {
    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
        modifier = modifier,
        cells = androidx.compose.foundation.lazy.grid.GridCells.Fixed(columns),
        contentPadding = contentPadding,
        verticalArrangement = verticalArrangement,
        horizontalArrangement = horizontalArrangement
    ) {
        content()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SNACKBAR / TOAST
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun ConnectSnackbarHost(modifier: Modifier = Modifier) {
    val snackbarHostState = remember { androidx.compose.material3.SnackbarHostState() }
    androidx.compose.material3.SnackbarHost(snackbarHostState, modifier = modifier)
}

@Composable
fun ConnectSnackbar(
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    duration: Int = androidx.compose.material3.SnackbarDuration.Short,
    backgroundColor: Color = MaterialTheme.colorScheme.inverseSurface,
    contentColor: Color = MaterialTheme.colorScheme.inverseOnSurface,
    actionColor: Color = MaterialTheme.colorScheme.primary
) {
    // Usage: LaunchedEffect(key) { ConnectSnackbar("Message") }
    // This is a helper - actual snackbar needs SnackbarHostState
    // Use ConnectSnackbarHost at root and SnackbarHostState.showSnackbar()
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun <T> rememberMutableState(initialValue: T): androidx.compose.runtime.SnapshotState<T> {
    return remember { mutableStateOf(initialValue) }
}

@Composable
fun <T> animateState(
    targetValue: T,
    animationSpec: androidx.compose.animation.core.AnimationSpec<T> = Anim.mediumSpring,
    label: String = "animateState"
): T {
    return animateStateAsState(targetValue, animationSpec, label).value
}

fun Modifier.animateScale(
    targetValue: Float,
    animationSpec: androidx.compose.animation.core.AnimationSpec<Float> = Anim.mediumSpring,
    label: String = "animateScale"
): Modifier {
    val scale by animateFloatAsState(targetValue, animationSpec, label)
    return this.graphicsLayer { scaleX = scale; scaleY = scale }
}

fun Modifier.animateColorAsState(
    targetValue: Color,
    animationSpec: androidx.compose.animation.core.AnimationSpec<Color> = Anim.mediumTween,
    label: String = "animateColor"
): Modifier {
    val color by animateColorAsState(targetValue, animationSpec, label)
    return this.background(color)
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPERIMENTAL: COORDINATE ANIMATIONS
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun <T> animateContentSize(
    modifier: Modifier = Modifier,
    animationSpec: androidx.compose.animation.core.FiniteAnimationSpec<IntSize> = Anim.mediumSpring
): Modifier {
    return modifier.animateContentSize(animationSpec)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectDropdownMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    anchor: androidx.compose.ui.layout.LayoutCoordinates? = null,
    items: List<DropdownItem>
) {
    if (!expanded) return

    androidx.compose.material3.DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        modifier = modifier,
        properties = androidx.compose.material3.DropdownMenuDefaults.MenuProperties(
            anchor = anchor,
            offset = DpOffset(0.dp, Spacing.space8)
        )
    ) {
        items.forEach { item ->
            androidx.compose.material3.DropdownMenuItem(
                text = { Text(text = item.label, style = TypeStyle.bodyMedium, color = item.textColor) },
                leadingIcon = item.icon?.let { { Icon(it, contentDescription = null, tint = item.iconColor) } },
                onClick = {
                    onDismiss()
                    item.onClick()
                },
                enabled = item.enabled,
                colors = androidx.compose.material3.DropdownMenuDefaults.dropdownMenuItemColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                )
            )
            if (item != items.last()) ConnectDivider(modifier = Modifier.padding(vertical = Spacing.xs))
        }
    }
}

data class DropdownItem(
    val label: String,
    val onClick: () -> Unit,
    val icon: ImageVector? = null,
    val iconColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    val textColor: Color = MaterialTheme.colorScheme.onSurface,
    val enabled: Boolean = true
)