package com.mitron.connect.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class ConnectColorScheme(
    // Surfaces
    val surface1: Color,
    val surface2: Color,
    val surface3: Color,
    val chatBubbleMe: Color,
    val chatBubbleOther: Color,

    // Text
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,

    // Borders
    val border: Color,
    val borderStrong: Color,
    val borderStronger: Color,

    // Primary Brand
    val fillPrimary: Color,
    val fillPrimaryDeep: Color,
    val onPrimary: Color,

    // Accent (Teal/Violet)
    val accent: Color,
    val accentBg: Color,

    // AI/Pro
    val pro: Color,
    val proBg: Color,

    // Semantic Colors
    val success: Color,
    val successBg: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val danger: Color,
    val dangerBg: Color,
    val dangerContainer: Color,
    val onDangerContainer: Color,
    val warn: Color,
    val warnBg: Color,
    val warnContainer: Color,
    val onWarnContainer: Color,

    // Brand Semantic
    val brand: Color,
    val brandContainer: Color,
    val onBrand: Color,
    val onBrandContainer: Color,

    // AI Semantic
    val ai: Color,
    val aiContainer: Color,
    val onAi: Color,
    val onAiContainer: Color,
) {
    companion object {
        val avatarColors = listOf(
            Color(0xFF4F46E5), // Indigo
            Color(0xFF7C3AED), // Violet
            Color(0xFF06B6D4), // Cyan
            Color(0xFF10B981), // Emerald
            Color(0xFFF59E0B), // Amber
            Color(0xFFEF4444), // Red
            Color(0xFFEC4899), // Pink
            Color(0xFF8B5CF6), // Purple
        )
    }
}

val LightConnectColors = ConnectColorScheme(
    // Surfaces
    surface1         = SurfaceLight1,
    surface2         = SurfaceLight2,
    surface3         = SurfaceLight3,
    chatBubbleMe     = ChatBubbleMeLight,
    chatBubbleOther  = ChatBubbleOtherLight,

    // Text
    textPrimary      = TextPrimaryLight,
    textSecondary    = TextSecondaryLight,
    textMuted        = TextMutedLight,

    // Borders
    border           = BorderLight,
    borderStrong     = BorderStrongLight,
    borderStronger   = BorderStrongerLight,

    // Primary Brand
    fillPrimary      = BrandBlue,
    fillPrimaryDeep  = BrandBlueDeep,
    onPrimary        = OnBrandBlue,

    // Accent (Violet)
    accent           = AccentTealLight,
    accentBg         = AccentTealBgLight,

    // AI/Pro
    pro              = AiIndigo,
    proBg            = AiIndigoBgLight,

    // Semantic Colors
    success          = SuccessGreen,
    successBg        = SuccessBgLight,
    successContainer = SuccessBgLight,
    onSuccessContainer = Color(0xFF065F46),
    danger           = DangerRed,
    dangerBg         = DangerBgLight,
    dangerContainer  = DangerBgLight,
    onDangerContainer = Color(0xFF7F1D1D),
    warn             = WarnAmber,
    warnBg           = WarnBgLight,
    warnContainer    = WarnBgLight,
    onWarnContainer  = Color(0xFF92400E),

    // Brand Semantic
    brand            = BrandBlue,
    brandContainer   = Color(0xFFE0E7FF),
    onBrand          = OnBrandBlue,
    onBrandContainer = Color(0xFF312E81),

    // AI Semantic
    ai               = AiIndigo,
    aiContainer      = AiIndigoBgLight,
    onAi             = OnBrandBlue,
    onAiContainer    = Color(0xFF312E81),
)

val DarkConnectColors = ConnectColorScheme(
    // Surfaces
    surface1         = SurfaceDark1,
    surface2         = SurfaceDark2,
    surface3         = SurfaceDark3,
    chatBubbleMe     = ChatBubbleMeDark,
    chatBubbleOther  = ChatBubbleOtherDark,

    // Text
    textPrimary      = TextPrimaryDark,
    textSecondary    = TextSecondaryDark,
    textMuted        = TextMutedDark,

    // Borders
    border           = BorderDark,
    borderStrong     = BorderStrongDark,
    borderStronger   = BorderStrongerDark,

    // Primary Brand
    fillPrimary      = BrandBlue,
    fillPrimaryDeep  = BrandBlueDeep,
    onPrimary        = OnBrandBlue,

    // Accent (Violet)
    accent           = AccentTealDark,
    accentBg         = AccentTealBgDark,

    // AI/Pro
    pro              = AiIndigo,
    proBg            = AiIndigoBgDark,

    // Semantic Colors
    success          = SuccessGreen,
    successBg        = SuccessBgDark,
    successContainer = SuccessBgDark,
    onSuccessContainer = Color(0xFFD1FAE5),
    danger           = DangerRed,
    dangerBg         = DangerBgDark,
    dangerContainer  = DangerBgDark,
    onDangerContainer = Color(0xFFFEE2E2),
    warn             = WarnAmber,
    warnBg           = WarnBgDark,
    warnContainer    = WarnBgDark,
    onWarnContainer  = Color(0xFFFEF3C7),

    // Brand Semantic
    brand            = Color(0xFF818CF8),
    brandContainer   = Color(0xFF4338CA),
    onBrand          = Color(0xFF312E81),
    onBrandContainer = Color(0xFFE0E7FF),

    // AI Semantic
    ai               = Color(0xFF818CF8),
    aiContainer      = Color(0xFF4338CA),
    onAi             = Color(0xFF312E81),
    onAiContainer    = Color(0xFFE0E7FF),
)

val LocalConnectColors = staticCompositionLocalOf { LightConnectColors }
